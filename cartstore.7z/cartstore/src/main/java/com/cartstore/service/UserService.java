package com.cartstore.service;

import java.util.List;

import com.cartstore.bean.SignUp;

public interface UserService {

	List<SignUp> getAllUsers();

	void createUser(SignUp user);

}
