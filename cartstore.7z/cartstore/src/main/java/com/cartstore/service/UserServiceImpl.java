package com.cartstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cartstore.bean.SignUp;
import com.cartstore.dao.UserDao;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;

	@Override
	public List<SignUp> getAllUsers() {

		return userDao.findAll();
	}

	@Override
	public void createUser(SignUp user) {
		userDao.save(user);
	}

}
