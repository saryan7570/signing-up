import { Component, OnInit } from '@angular/core';
import { StoreService } from '../store.service';
import { SignUp } from '../signup';

@Component({
  selector: 'signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  storeService: StoreService;
  user: SignUp;
  constructor(storeService: StoreService) {
    this.storeService = storeService;
    // this.user = new SignUp();
  } 

  ngOnInit() {
  }

  signUp(details): void {
    console.log(details);
    this.user = details;
    this.storeService.create(this.user).subscribe(data => {
      alert("Account created successfully.");
    });
  }
}
